package com.pradeepsoft.postmaker;

import android.app.*;
import android.os.*;
import android.graphics.drawable.*;
import android.widget.*;
import android.graphics.*;
import java.io.*;
import java.util.*;
import android.view.View;
import android.view.*;
import android.provider.*;
import android.net.*;
import android.text.*;


public class MainActivity extends Activity 
{
	ImageView imv;
	EditText colorText;
	Button save;
	Button setPoint;
	Button refresh; 

	Bitmap imgR;
	Bitmap imgNew=null;
	int viewPX=0;
	int viewPY=0;
	int viewCX=0;
	int viewCY=0;
	long mTime=0;
	int pointX=0;
	int pointY=0;
	List<int[]> cords=new ArrayList<int[]>();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

		imv = (ImageView) findViewById(R.id.imv);
	    colorText = (EditText)findViewById(R.id.colorText);
		save = (Button) findViewById(R.id.save);
		//setPoint = (Button) findViewById(R.id.setPoint);
		refresh = (Button) findViewById(R.id.refresh);

		imv.setImageBitmap(imgNew);

		save.setOnClickListener(new View.OnClickListener(){
				public void onClick(View v)
				{
					writeImageGallery(imgNew);
				}
			});

		colorText.setOnClickListener(new View.OnClickListener(){
				public void onClick(View v)
				{

				}
			});

		/*colorText.setOnKeyListener(new View.OnKeyListener(){
		 public boolean onKey(View v, int i, KeyEvent k)
		 {
		 try
		 {
		 String[] a =colorText.getText().toString().replace(" ", "").split(",");
		 int co=Color.rgb(Integer.parseInt(a[0]), Integer.parseInt(a[1]), Integer.parseInt(a[2]));
		 c.setBackgroundColor(co);
		 }
		 catch (Exception ex)
		 {

		 }
		 return false;
		 }
		 });*/

		refresh.setOnClickListener(new View.OnClickListener(){
				public void onClick(View v)
				{
					imgNew = createBitmap(imv.getMeasuredWidth(), imv.getMeasuredHeight(), new Color().argb(255, 255, 255, 255));
					imv.setImageBitmap(imgNew);
				}
			});

		imv.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event)
				{
					viewCX = (int)event.getX();
					viewCY = (int)event.getY();
					drawArt();
					return true;
				}
			});



	}

	public Bitmap readImageResource(int id)
	{
		BitmapDrawable bitD = (BitmapDrawable)getResources().getDrawable(id);
		Bitmap bit=bitD.getBitmap();		
		return bit;
	}

	public Bitmap readImageFile(String file)
	{
		Bitmap bit =BitmapFactory.decodeFile(file);
		return bit;
	}

	public void writeImageFile(Bitmap bit, String file)
	{
		try
		{
			FileOutputStream out = null;
			try
			{
				out = new FileOutputStream(file);
				bit.compress(Bitmap.CompressFormat.PNG, 100, out); 
			}
			finally
			{
				out.close();
			}
		}
		catch (IOException ex)
		{
		}
	}

	public Bitmap readImageGallery()
	{
		Bitmap bit=null;	
		return bit;
	}

	public void writeImageGallery(Bitmap bit)
	{
		MediaStore.Images.Media.insertImage(getContentResolver(), bit, String.valueOf(new Date().getTime()) , "PostMakerImage");
	}

	public Bitmap createBitmap(int width, int height, int color)
	{
		Bitmap bit= Bitmap.createBitmap(width,	height, Bitmap.Config.ARGB_8888);
		for (int x=0;x < width;x++)
		{
			for (int y=0;y < height;y++)
			{
				bit.setPixel(x, y, color);
			}
		}
		return bit;
	}

	public void drawArt()
	{
		if (imgNew == null)
		{
			imgNew = createBitmap(imv.getMeasuredWidth(), imv.getMeasuredHeight(), new Color().argb(255, 255, 255, 255));
			imv.setImageBitmap(imgNew);
		}
		if ((new Date().getTime() - mTime) > 10)
		{
			mTime = new Date().getTime();

			String[] cls= colorText.getText().toString().replace(" ", "").split(",");
			try
			{
				int r=Integer.parseInt(cls[0]);
				int g=Integer.parseInt(cls[1]);
				int b=Integer.parseInt(cls[2]);
				viewPX = Integer.parseInt(cls[3]);
				viewPY = Integer.parseInt(cls[4]);

				Paint p=new Paint();
				p.setStrokeWidth(5);
				p.setColor(new Color().rgb(r, g, b));

				Canvas cv=new Canvas();
				cv.setBitmap(imgNew);

				if ((viewPX != -1) && (viewPY != -1))
				{
					cv.drawLine(viewPX, viewPY, viewCX, viewCY, p);
				}

				imv.setImageBitmap(imgNew);
			}
			catch (Exception ex)
			{
			}
		}
	}

}
